package CarRentalAgency;

public class Car {

}
