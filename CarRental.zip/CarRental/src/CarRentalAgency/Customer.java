package CarRentalAgency;

public class Customer {

}
